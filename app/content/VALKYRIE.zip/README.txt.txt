Copy the Valkrye.vst3 folder to the following destination:

C:\Program Files\Common Files\VST3